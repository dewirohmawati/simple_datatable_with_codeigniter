<?php

	class Admin_model extends CI_Model {
		var $table = 'admin';
		var $id = 'nim';
		
		public function __construct() {
			parent::__construct();
		}
		
		public function insert_admin($data) {
			$this->db->insert("admin", $data);
			
			return $this->db->insert_id();
		}
		
		public function update_admin($nims, $data) {
			$this->db->where($nims);
			$this->db->update($this->table, $data);
		}
		
		public function fetch_admin_by_id($id) {
			$this->db->from($this->table);
			$this->db->where($this->id, $id);
			
			$query = $this->db->get();
			
			if($query->num_rows() != -1)
				return $query->result();
		}
		
		public function delete_admin($id) {
			$this->db->where("nim", $id);
			$this->db->delete($this->table);
		} 
		
		//datatable function
		private function datatable_query() {
			$this->db->from($this->table);
			
			return $this->db->get();
		}
		
		public function get_datatable_resultset() {
			
			return $this->datatable_query()->result();
		}
		
		public function count_rows_filtered() {
			return $this->datatable_query()->num_rows();
		}
		
		public function count_rows() {
			$query = $this->db->from($this->table);
			
			return $this->db->count_all_results();
		}
	}
	
?>