<?php
	
	class Foto_model extends CI_Model {
		
		public function __construct() {
			parent::__construct();
		}
		
		public function insert_foto($data) {
			$this->db->insert("foto", $data);
		}
		
		public function fetch_all_foto_by_laundry_id($laundry_id) {
			$this->db->select("*");
			$this->db->where("id_laundry", $laundry_id);
			$query = $this->db->get("foto");
			
			if($query->num_rows() > 0)
				return $query->result();
			else 
				return null;
		}
		
		public function update_foto($ids, $data) {
			$this->db->where($ids);
			$this->db->update("foto", $data);
		}
		
	}
	
?>