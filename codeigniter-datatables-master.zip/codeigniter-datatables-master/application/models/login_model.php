<?php

	class Login_model extends CI_Model {
		var $table = 'admin';
		
		public function __construct() {
			parent::__construct();
		}
		
		public function do_login($nim, $password) {
			$this->db->from($this->table);
			$this->db->where("nim", $nim);
			$this->db->where("password", $password);
			$query = $this->db->get();
			
			if($query->num_rows() != 0) 
				return true;
			else 
				return false;
		}
		
	}

?>