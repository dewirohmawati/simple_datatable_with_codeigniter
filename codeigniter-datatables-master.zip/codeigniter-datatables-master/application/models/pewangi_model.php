<?php

	class Pewangi_model extends CI_Model {
		
		public function __construct() {
			parent::__construct();
		}
		
		public function get_all_pewangi() {
			$this->db->select("id_pewangi, nama_pewangi");
			$this->db->from("pewangi");
			$query = $this->db->get();
			
			return	$query->result();
		}
		
	}

?>