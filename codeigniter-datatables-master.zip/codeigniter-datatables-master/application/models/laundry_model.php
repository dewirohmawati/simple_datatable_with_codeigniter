<?php
	class Laundry_model extends CI_Model {
		
		public function __construct() {
			parent::__construct();
		}
		
		function insert_laundry($data) {
			$this->db->insert("laundry", $data);
		}
		
		function count_all_laundry() {
			return $this->db->count_all("laundry");
		}
		
		function fetch_all_laundries() {
			$query = $this->db->get("laundry")->result_array();
			
			foreach($query as $i=>$laundry) {
				$this->db->where("id_laundry", $laundry["id_laundry"]);
				$this->db->group_by("id_laundry");
				$photo = $this->db->get("foto")->result();
				
				$query[$i]["foto"] = $photo; 
			}
			
			return $query;
		}
		
				
		function fetch_laundry_by_id($id) {
			$this->db->select("*");
			$this->db->where("id_laundry", $id);
			$query = $this->db->get("laundry")->result_array();
			
			foreach($query as $i=>$laundry) {
				$this->db->select("time, foto");
				$this->db->where("id_laundry", $laundry["id_laundry"]);
				$this->db->group_by("id_laundry");
				$photo = $this->db->get("foto")->result();
				
				$query[$i]["foto"] = $photo; 
			}
			
			return $query;
		}
		
		function fetch_laundry_by_name($name) {
			$this->db->select("*");
			$this->db->where("nama_laundry", $name);
			$query = $this->db->get("laundry")->result_array();
			
			foreach($query as $i=>$laundry) {
				$this->db->select("time, foto");
				$this->db->where("id_laundry", $laundry["id_laundry"]);
				$this->db->group_by("id_laundry");
				$photo = $this->db->get("foto")->result();
				
				$query[$i]["foto"] = $photo; 
			}
			
			return $query;
		}
		
		function fetch_laundries($limit, $offset) {
			$this->db->limit($limit, $offset);	
			$this->db->select("id_laundry, nama_laundry, alamat");
			$query = $this->db->get("laundry")->result_array();
			
			foreach($query as $i=>$laundry) {
				$this->db->where("id_laundry", $laundry["id_laundry"]);
				$this->db->group_by("id_laundry");
				$photo = $this->db->get("foto")->result();
				
				$query[$i]["foto"] = $photo; 
			}
			
			return $query;
		}
		

		function update_laundry($id, $data) {
			$this->db->where("id_laundry", $id);
			$this->db->update("laundry", $data);
		}
	}
?>











