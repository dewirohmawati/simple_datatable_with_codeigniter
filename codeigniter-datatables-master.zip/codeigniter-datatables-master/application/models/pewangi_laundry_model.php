<?php
	
	class Pewangi_laundry_model extends CI_Model {
		
		public function __construct() {
			parent::__construct();
		}
		
		public function insert_pewangi_laundry($data) {
			$this->db->insert("pewangi_laundry", $data);
		}
		
	}
	
?>