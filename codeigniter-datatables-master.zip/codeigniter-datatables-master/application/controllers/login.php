<?php

	class Login extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->helper("url");
			$this->load->database();
			$this->load->model("Login_model");
		}
		
		public function index() {
			$this->load->view("login_view");
		}
		
		public function submitted_login() {
			$status = $this->Login_model->do_login($this->input->post("username"), $this->input->post("password"));
			
			if($status)
				echo "Hai";
			else
				echo "Failed";
		}
	}

?>