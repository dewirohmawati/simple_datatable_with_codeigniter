<?php

	class Fetch_all extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->model("Laundry_model");
			$this->load->database();
		}
		
		public function fetch() {
			$this->db->limit(10);
			$data['records'] = $this->Laundry_model->fetch_all_laundries();
			$this->load->view("fetch_view", $data);
		}
	}

?>