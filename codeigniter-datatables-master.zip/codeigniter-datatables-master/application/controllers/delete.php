<?php

	class Delete extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->database();
			$this->load->model("Laundry_model");
		}
		
		public function delete_laundry($id_laundry) {
			echo "Hai from server";
		}
		
	}

?>