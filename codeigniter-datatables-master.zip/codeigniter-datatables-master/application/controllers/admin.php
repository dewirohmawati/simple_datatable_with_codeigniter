<?php

	class Admin extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->database();
			$this->load->model("Admin_model");
			$this->load->helper("url");
		}
		
		public function index() {
			$this->load->view("admin_view");
		}
		
		// Below functions for ajax call only
		public function ajax_save() {	
			$data = array(
				"nim" => $this->input->post("nim"),
				"nama" => $this->input->post("nama"),
				"password" => $this->input->post("password"),
				"tgl_lahir" => $this->input->post("tgl-lahir"),
				"kontak" => $this->input->post("kontak"),
				"jenis_kelamin" => $this->input->post("jenis-kelamin"),
				"alamat" => $this->input->post("alamat")
			);
			
			$this->Admin_model->insert_admin($data);
			
			echo json_encode(array("status" => TRUE));
		}
		
		public function ajax_update($id) {
			$nim = $id;
			
			$ids = array(
				"nim" => $nim
			);

			$data = array(
				"nim" => $this->input->post("nim"),
				"nama" => $this->input->post("nama"),
				"password" => $this->input->post("password"),
				"tgl_lahir" => $this->input->post("tgl-lahir"),
				"kontak" => $this->input->post("kontak"),
				"jenis_kelamin" => $this->input->post("jenis-kelamin"),
				"alamat" => $this->input->post("alamat")
			);
			
			$this->Admin_model->update_admin($ids, $data);
			
			echo json_encode(array("status" => TRUE));
		}
		
		public function ajax_delete($id) {
			$this->Admin_model->delete_admin($id);
			
			echo json_encode(array(
				"status" => "success"
			));
		}
		
		public function ajax_datatable_list() {
			$resultset = $this->Admin_model->get_datatable_resultset();
			$start = $this->input->post("start");
			$data = array();
			
			foreach($resultset as $admin) {
				$row = array();
				
				$row[] = $admin->nim;
				$row[] = $admin->nama;
				$row[] = $admin->kontak;
				$row[] =  
				'<a class="btn btn-sm btn-primary" 
					href="javascript:void(0)" 
					title="Edit" 
					onclick="onShowDialogEditAdmin('."'". $admin->nim ."'".')">
					<i class="glyphicon glyphicon-pencil"></i> Edit
				</a>'.
				'&nbsp;&nbsp;'.
				'<a class="btn btn-sm btn-danger" 
                	href="javascript:void(0)" 
                	title="Hapus" 
                	onclick="onShowDialogDeleteAdmin('."'". $admin->nim ."'".')">
                	<i class="glyphicon glyphicon-trash"></i> Delete
                </a>';
                
                $data[] = $row;
			}
			
			$output = array(
            	"draw" => $_POST['draw'],
                "recordsTotal" => $this->Admin_model->count_rows(),
                "recordsFiltered" => $this->Admin_model->count_rows_filtered(),
                "data" => $data,
            );
        
        	echo json_encode($output);
		}
		
		public function ajax_get_admin_by_id($nim) {
			$resultset = $this->Admin_model->fetch_admin_by_id($nim);
			
			echo json_encode($resultset);
		}
		
	}

?>