<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		$this->load->helper("url");
		$this->load->database();
		$this->load->model("Laundry_model");
		$this->load->library("pagination");
	}
	
	public function index($page=0) {
		$config = array(
			"base_url" => base_url() ."/index",
			"total_rows" => $this->Laundry_model->count_all_laundry(),
			"per_page" => 5,
			"use_page_number" => TRUE,
			"num_links" => $this->Laundry_model->count_all_laundry(),
			"cur_tag_open" => '&nbsp;<a class="current">',
			"cur_tag_close" => '</a>',
			"prev_link" => "Previous",
			"next_link" => "Next"
		);
		
		$this->pagination->initialize($config);
			
		$data["records"] = $this->Laundry_model->fetch_laundries($config["per_page"], $page);
		$data["links"] = explode("&nbsp;", $this->pagination->create_links());
		
		$this->load->view("home_view", $data);
	}
	
}

?>