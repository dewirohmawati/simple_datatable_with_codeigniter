<?php

	class Edit extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->model("Laundry_model");
			$this->load->model("Foto_model");
			$this->load->database();
			$this->load->helper(array(
				"url",
				"form"
			));
		}
		
		public function edit_laundry($id) {
			$laundry = $this->Laundry_model->fetch_laundry_by_id($id);
			$laundry_foto = $this->Foto_model->fetch_all_foto_by_laundry_id($id);
			
			if($laundry != null) {
				$data["laundry"] = $laundry;
				$data["foto"] = $laundry_foto;
				
				$this->load->view("edit_laundry_by_id_view", $data);
			}
		}
		
		public function submitted_update_laundry() {
			$id_laundry = $this->input->post("id-laundry");
			$latitude_longitude = explode(":", $this->input->post("latitude_longitude"));
			$foto1 = $_FILES['foto1']['name'];
			$foto2 = $_FILES['foto2']['name'];
			$foto3 = $_FILES['foto3']['name'];
			
			$data = array(
				"nama_laundry" => $this->input->post("nama-laundry"),
				"alamat" => $this->input->post("alamat"),
				"no_hp" => $this->input->post("no-hp"),
				"deskripsi" => $this->input->post("deskripsi"),
				"latitude" => $latitude_longitude[0],
				"longitude" => $latitude_longitude[1],
				"harga" => $this->input->post("harga")
			);
			
			$this->Laundry_model->update_laundry($id_laundry, $data);
			
			$config = array(
				"upload_path" => "./assets/images/uploaded_images/laundry_images/",
				"allowed_types" => "gif|jpg|jpeg|png",
				"overwrite" => TRUE,
				"max_size"	=> "1000",
				"max_width"  => "2000",
				"max_height"  => "2000"
			);
		
			$this->load->library("upload", $config);
			$this->upload->initialize($config);
		
			$photos = $this->Foto_model->fetch_all_foto_by_laundry_id($id_laundry);	
			
			if($foto1 != '') {
				$foto1_time_id = $this->input->post("foto1-time-id");
				
				$ids = array(
					"id_laundry" => $id_laundry,
					"time" => $foto1_time_id
				);
				
				$status = $this->do_upload("foto1");
				
				$data = array(
					"foto" => $status["message"]["file_name"]
				);
				
				$this->Foto_model->update_foto($ids, $data);
			} 
			
			if($foto2 != '') {
				$foto2_time_id = $this->input->post("foto2-time-id");
				
				$ids = array(
					"id_laundry" => $id_laundry,
					"time" => $foto2_time_id
				);
				
				$status = $this->do_upload("foto2");
				
				$data = array(
					"foto" => $status["message"]["file_name"]
				);
				
				$this->Foto_model->update_foto($ids, $data);
			}
			
			if($foto3 != '') {
				$foto3_time_id = $this->input->post("foto3-time-id");
				
				$ids = array(
					"id_laundry" => $id_laundry,
					"time" => $foto3_time_id
				);
				
				$status = $this->do_upload("foto3");
				
				$data = array(
					"foto" => $status["message"]["file_name"]
				);
				
				$this->Foto_model->update_foto($ids, $data);
			}
			
			redirect("/home");
		}
		
		private function do_upload($input_name) {
			if($this->upload->do_upload($input_name)) {
				return 	array(
					"status" => "success",
					"message" => $this->upload->data()
				);
			} else {
				//displaying error upload
				echo $this->upload->display_errors();
				
				return array(
					"status" => "failed",
					"message" => $this->upload->display_errors()
				);
			}
		}
	}

?>