<?php

	class Android extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->model("Laundry_model");
			$this->load->database();
		}
		
		public function get_all_laundry() {
			$data = $this->Laundry_model->fetch_all_laundries();
			
			echo json_encode($data);
		}
		
		public function get_laundry_by_id($id) {
			$this->load->model("Foto_model");
			
			$data = $this->Laundry_model->fetch_laundry_by_id($id);
			
			echo json_encode($data);
		}
		
		public function search($laundry) {
			$this->load->model("Foto_model");
			
			$data = $this->Laundry_model->fetch_laundry_by_name($laundry);
			
			echo json_encode($data);
		}
		
	}

?>