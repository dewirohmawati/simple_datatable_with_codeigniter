<?php 

	class Upload_manager {
		private $config = array();
		
		public function set_upload_config() {
			$this->$config = array(
				"upload_path" => "./images",
				"allowed_types" => "gif|jpg|png",
				"max_size" => "1000",
				"overwrite" => FALSE
			);
		}
		
		public function do_upload() {
			
		}
		
	}

?>