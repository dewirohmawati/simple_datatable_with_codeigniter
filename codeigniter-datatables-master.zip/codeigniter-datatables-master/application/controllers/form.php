<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Form extends CI_Controller {

	public function __construct() {
		parent::__construct();
		
		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->database();
		$this->load->model("Laundry_model");
		$this->load->model("Foto_model");
	}
	
	public function form_input_data_laundry() {
		$this->load->view("form_input_data_laundry_view");	
	}
	
	public function submitted_form_data_laundry() {
		$id_laundry = time();
		$data_laundry = array(
			"id_laundry" => $id_laundry,
			"nama_laundry" => $this->input->post("nama-laundry"),
			"alamat" => $this->input->post("alamat"),
			"no_hp" => $this->input->post("no-hp"),
			"deskripsi" => $this->input->post("deskripsi"),
			"latitude" => $this->input->post("latitude"),
			"longitude" => $this->input->post("longitude"),
			"harga" => $this->input->post("harga")
		);
		
		$this->Laundry_model->insert_laundry($data_laundry);

		$config = array(
			"upload_path" => "./assets/images/uploaded_images/laundry_images/",
			"allowed_types" => "gif|jpg|jpeg|png",
			"overwrite" => FALSE,
			"max_size"	=> "1000",
			"max_width"  => "2000",
			"max_height"  => "2000"
		);
		
		$this->load->library("upload", $config);
		$this->upload->initialize($config);
		
		$status1 = $this->do_upload("foto1");
		$status2 = $this->do_upload("foto2");
		$status3 = $this->do_upload("foto3");
		
		if($status1["status"] != "failed" || $status2["status"] != "failed" ||  $status3["status"] != "failed") {
			if(($status1["status"] != "failed")) {
				$data = array(
					"id_laundry" => $id_laundry,
					"foto" => $status1["message"]["file_name"]
				);
				
				$this->Foto_model->insert_foto($data);
			} 
				
			if(($status2["status"] != "failed")) {
				$data = array(
					"id_laundry" => $id_laundry,
					"foto" => $status2["message"]["file_name"]
				);
					
				$this->Foto_model->insert_foto($data);
			} 
				
			if(($status3["status"] != "failed")) {
				$data = array(
					"id_laundry" => $id_laundry,
					"foto" => $status3["message"]["file_name"]
				);
					
				$this->Foto_model->insert_foto($data);
			}
				
			$this->load->library('../controllers/form');
			$this->form->form_input_data_laundry();
		}
	}	
	
	private function do_upload($input_name) {
		if($this->upload->do_upload($input_name)) {
			return 	array(
				"status" => "success",
				"message" => $this->upload->data()
			);
		} else {
			echo $this->upload->display_errors();
			return array(
				"status" => "failed",
				"message" => $this->upload->display_errors()
			);
		}
	}
	
}

?>















