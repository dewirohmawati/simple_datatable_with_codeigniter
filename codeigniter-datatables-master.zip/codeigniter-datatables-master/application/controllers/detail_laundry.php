<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Detail_laundry extends CI_Controller {
		
		public function __construct() {
			parent::__construct();
			
			$this->load->helper("url");
			$this->load->database();
			$this->load->model("Laundry_model");
			$this->load->model("Foto_model");
		}

		public function get_detail($id_laundry=0) {
			if($id_laundry != 0) {
				$resultset = $this->Laundry_model->fetch_laundry_by_id($id_laundry);
				$laundry = $resultset[0];
				
				$foto_laundry = $this->Foto_model->fetch_all_foto_by_laundry_id($laundry->id_laundry);
				 
				$data["laundry"] = $laundry;
				$data["foto"] = $foto_laundry;
				
				$this->load->view("detail_laundry_view", $data); 
			} else
				exit('Cannot proceed, No ID found!');
		}
	}
?>