<?php 

	class Upload_Manager {
		private $config = array();
		private $CI;
		
		public function __construct() {
		}
		
		public function Upload_Manager($CI) {
			$this->CI = $CI;
		}
		
		public function set_upload_config() {
			$this->config = array(
				"upload_path" => "http://localhost/lbslaundry/assets/images/",
				"allowed_types" => "gif|jpg|png",
				"max_size" => "1000",
				"overwrite" => FALSE
			);
			
			$this->CI->load->library("upload", $this->config);
		}
		
		public function do_upload() {
			if($this->CI->upload->do_upload())
				$this->CI->load->view("success_view");
		}
		
	}

?>