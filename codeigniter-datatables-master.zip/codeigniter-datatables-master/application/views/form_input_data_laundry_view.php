<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<script src="https://code.jquery.com/jquery.js"></script>
		<title>Laundry Online</title>

		<!-- Bootstrap Core CSS -->
		<link href="<?php echo base_url(); ?>/assets/css/bootstrap.css" rel="stylesheet">
		<script src="<?php echo base_url(); ?>/assets/js/bootstrap-filestyle.min.js"></script>
		<script src="<?php echo base_url(); ?>/assets/js/jquery.validate.min.js"></script>
		<style type="text/css">
			.header img {
				height: 200px;
				width: 945px;
			}

			body {
				margin: 10px;
			}

			.content {
				background-color: blue;
			}

			.no-margin {
				margin: 0px;
			}

			#form-border {
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				border-bottom: 1px solid #E0E0E0;
				padding: 25px 20px 25px 20px;
				border-radius: 0px 0px 5px 5px;
			}

			#form-header {
				border-top: 1px solid #E0E0E0;
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				background-color: #FFF9C4;
				padding: 20px 10px 20px 10px;
				border-radius: 5px 5px 0px 0px;
			}

			#separator {
				border-top: 1px solid #E0E0E0;
				display: inline block;
			}

			.form-width {
				width: 700px;
			}

			.btn-file {
				position: relative;
				overflow: hidden;
			}

			.btn-file input[type=file] {
				position: absolute;
				top: 0;
				right: 0;
				min-width: 100%;
				min-height: 100%;
				font-size: 100px;
				text-align: right;
				filter: alpha(opacity=0);
				opacity: 0;
				outline: none;
				background: white;
				cursor: inherit;
				display: block;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<?php
			include("header.php");
			?>
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">
					<div id="form-header">
						<h4 class="no-margin">Halaman ini berfungsi untuk mengisi data laundry</h4>
					</div>
					<div id="separator"></div>
					<div id="form-border">
						<?php
						$attributes = array(
							"id" => "form-laundry"
						);
						echo form_open_multipart("form/submitted_form_data_laundry", $attributes);
						echo "<div class='form-group' style='width: 400px'>";
						echo form_label("Nama Laundry", "nama laundry");

						$data = array(
							"name" => "nama-laundry",
							"type" => "text",
							"id" => "nama-laundry",
							"class" => "form-control",
							"placeholder" => "Masukkan nama laundry",
						);

						echo form_input($data);
						echo "</div>";

						echo "<div class='form-group' style='width: 700px'>";
						echo form_label("Alamat", "alamat");

						$data = array(
							"name" => "alamat",
							"type" => "text",
							"id" => "alamat",
							"class" => "form-control",
							"placeholder" => "Masukkan alamat",
						);

						echo form_input($data);
						echo "</div>";

						echo form_label("Kontak", "kontak");
						echo "<div class='input-group col-md-5'>";
						echo "<span class='input-group-addon' id='basic-addon1'>No HP</span>";

						$data = array(
							"name" => "no-hp",
							"type" => "number",
							"id" => "no-hp",
							"placeholder" => "contoh : 085000898797",
							"class" => "form-control",
							"aria-describedby" => "basic-addon1"
						);

						echo form_input($data);
						echo "</div>";
						echo "</br>";
						echo "<div class='form-group' style='width: 355px'>";
						echo form_label("Latitude Longitude", "latitude-longitude");

						$data = array(
							"name" => "latitude_longitude",
							"type" => "text",
							"id" => "latlong",
							"class" => "form-control",
							"value" => "-7.7972:110.3688",
							"placeholder" => "4773874.474, 48394348.484",
						);

						echo form_input($data);
						
						$data = array(
							"name" => "latitude",
							"type" => "hidden",
							"id" => "latitude",
						);
						
						echo form_input($data);
						
						$data = array(
							"name" => "longitude",
							"type" => "hidden",
							"id" => "longitude",
						);
						
						echo form_input($data);
						?>
						<small><font color="red">NB:</font> Masukkan latitude dan longitude dengan pemisah semicolon (:)</small>
						<div id="map" style="height: 350px; width: 580px; margin-top: 10dp;"></div>
		
						<?php
						echo "</div>";

						echo "<div class='form-group' style='width: 450px'>";

						echo form_label("Deskripsi", "deskripsi");

						$data = array(
							"name" => "deskripsi",
							"type" => "text",
							"id" => "deskripsi",
							"class" => "form-control",
							"maxlength" => "300",
							"size" => "80",
							"placeholder" => "Masukkan deskripsi",
						);

						echo form_textarea($data);
						echo "<small>Deskripsi laundry (maksimal 300 kata)</small>";
						echo "</div>";

						echo "<div class='form-group' style='width: 450px'>";

						echo form_label("Foto", "foto");

						$data = array(
							"name" => "foto1",
							"type" => "file",
							"id" => "foto1",
						);

						echo form_input($data);
						echo "<div id='preview-foto-1'></div>";
						echo "<br/>";

						$data = array(
							"name" => "foto2",
							"type" => "file",
							"id" => "foto2",
						);

						echo form_input($data);
						echo "<div id='preview-foto-2'></div>";
						echo "<br/>";

						$data = array(
							"name" => "foto3",
							"type" => "file",
							"id" => "foto3",
						);

						echo form_input($data);
						echo "<div id='preview-foto-3'></div>";
						echo "</div>";

						echo form_label("Harga Per Kg", "harga-per-kg");
						echo "<div class='input-group col-md-5'>";
						echo "<span class='input-group-addon' id='basic-addon1'>Rp</span>";

						$data = array(
							"name" => "harga",
							"type" => "number",
							"id" => "harga",
							"placeholder" => "Masukkan harga",
							"class" => "form-control",
							"aria-describedby" => "basic-addon1"
						);

						echo form_input($data);
						echo "</div>";
						
						echo "<br/>";
						
						echo "<div class='form-group'>";

						$data = array(
							"name" => "submit",
							"type" => "submit",
							"value" => "Submit",
							"class" => "btn btn-primary"
						);

						echo form_input($data);
						echo "</div>";
						?>

					</div>
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
		<script>
			var map;
			var latitude;
			var longitude;
			
			function initMap() {
				map = new google.maps.Map(document.getElementById("map"), {
						center: {
							lat: -7.7972, 
							lng: 110.3688
						},
						zoom: 15
				});
			}
						
			function pan(latitude, longitude) {
        		var panPoint = new google.maps.LatLng(latitude, longitude);
        		
        		map.panTo(panPoint)
			}
			
			    		
    		function toRp(digit) {
				var digitReverse = parseInt(digit, 10).toString().split('').reverse().join('');
				var formattedDigit = '';
				
				for(var i = 0; i < digitReverse.length; i++) {
					formattedDigit += digitReverse[i];
					
					if((i + 1) % 3 === 0 && i !== (digitReverse - 1))
						formattedDigit += '.';
				}
				
				return 'Rp. '+ formattedDigit.split('').reverse().join('') +',00';
			}
			
			$(function() {
				$("#latlong").keyup(function() {
					var pattern = /\d:\d/;
					var splitLatLong = [];
					
					if(pattern.test($("#latlong").val())) {
						splitLatLong = $("#latlong").val().split(":");
						latitude = splitLatLong[0];
						longitude = splitLatLong[1];

						$("#latitude").val(latitude);
						$("#longitude").val(longitude);
						
						pan(latitude, longitude);		
					}
				})
			});
		</script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCkErBkJIkqzD0-2aHPIGC4HCdl4C2CQ6o&callback=initMap"
    async defer></script>
	</body>
</html>









