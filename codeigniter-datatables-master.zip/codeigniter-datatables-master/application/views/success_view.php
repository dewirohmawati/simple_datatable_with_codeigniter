<html>
	<body>
		fbvhfdbvfdjhfbv
		<?php
			echo $error;
		?>
	</body>
</html>