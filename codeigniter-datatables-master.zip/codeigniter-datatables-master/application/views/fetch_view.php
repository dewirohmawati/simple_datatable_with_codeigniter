<?php

	foreach($records as $row) {
		echo $row->nama_laundry;
		echo "<br/>";
	}

?>