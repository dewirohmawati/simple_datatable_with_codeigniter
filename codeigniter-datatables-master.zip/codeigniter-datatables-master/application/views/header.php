<html>
	<div class="row">
		<div class="col-lg-1"></div>
		<div class="col-lg-10">
			<div class="header">
				<img class="img-responsive" src="<?php echo base_url(); ?>/assets/images/ban.jpg"/>
			</div>
		</div>
		<div class="col-lg-1"></div>
	</div>
	<div class="row">
		<div class="col-lg-1"></div>
		<div class="col-lg-10">
			<nav class="navbar navbar-default">
				<div class="container-fluid">
					<ul class="nav navbar-nav">
						<li class=""><a href="<?php echo base_url(); ?>">Home</a></li>
						<li class="" ><a href="<?php echo base_url(); ?>index.php/form/form_input_data_laundry">Input Data</a></li>
						<li><a href="<?php echo base_url(); ?>index.php/admin/">Admin</a></li>
						<li><a href="#">About</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
					<!--
						<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
						<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
					-->
					</ul>
				</div>
			</nav>
			<hr/>
		</div>
		<div class="col-lg-1"></div>
	</div>
</html>