<html>
	<a href="<?php echo $row['id_laundry']; ?>" class="btn btn-danger delete-laundry-modal" data-toggle="modal" data-target=".modal-delete">Delete</a>
	<div class="modal fade modal-delete" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
				</div>
				<div class="modal-body">
					<h3>Anda akan mengapus <div id="id-content"></div></h3>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
					<button type="button" class="btn btn-danger">Delete</button>
				</div>
			</div>
		</div>
	</div
</html>