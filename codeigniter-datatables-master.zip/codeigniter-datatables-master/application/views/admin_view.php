<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<title>Laundry Online</title>

    	<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>  
		<!-- Bootstrap Core CSS -->
		<link href="<?php echo base_url(); ?>/assets/css/bootstrap.css" rel="stylesheet">
		<!-- Datepicker css -->
		<link href="<?php echo base_url(); ?>/assets/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    
		<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
		<script src="<?php echo base_url('assets/datatables/js/dataTables.bootstrap.js')?>"></script>
		<!-- Datepicker JS -->
		<script src="<?php echo base_url(); ?>/assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
		<style type="text/css">
			.header img {
				height: 200px;
				width: 945px;
			}

			body {
				margin: 10px;
			}

			.content {
				background-color: blue;
			}

			.no-margin {
				margin: 0px;
			}

			#form-border {
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				border-bottom: 1px solid #E0E0E0;
				padding: 25px 20px 25px 20px;
				border-radius: 0px 0px 5px 5px;
			}

			#form-header {
				border-top: 1px solid #E0E0E0;
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				background-color: #FFF9C4;
				padding: 20px 10px 20px 10px;
				border-radius: 5px 5px 0px 0px;
			}

			#separator {
				border-top: 1px solid #E0E0E0;
				display: inline block;
			}
			
			#form-border p {
				color: #a09492;
			}
			
			#form-border h3 {
				color: #555852;
			}
			
			#insert-status-message {
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				padding: 10px 10px 10px 10px;
				display: none;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<?php
				include("header.php");
			?>
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">
					<div id="form-header">
						<h4 class="no-margin">Halaman Admin</h4>
					</div>
					<div id="insert-status-message">dsdsds</div>
					<div id="separator"></div>
					<div id="form-border">
						<div class="table-responsive">
							<table id="table-admin" class="table table-hover">
								<thead>
									<tr>
										<th>NIM</th>
										<th>Nama</th>
										<th>Kontak</th>
										<th style="width: 125px;">Aksi</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
						<hr/>
						<button onclick="showModalTambahAdmin()" id="btn-tambah-admin" class="btn btn-md btn-success"><span class="glyphicon glyphicon-plus"></span> Tambah Admin</button>
					</div>
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
		<script type="text/javascript">
			var saveMethod = 'save';
			var id;
			var that = this;
			var datatable;
		
			$(function() {
				datatable = $("#table-admin").DataTable({
					"processing": true,
					"serverSide": true,
					"order": [],
					"ajax": {
						"url": "http://localhost/lbslaundry/index.php/admin/ajax_datatable_list",
						"type": "POST"
					},
					"columnDefs": [  //Set column definition initialisation properties.
						{
							"targets": [-1],
							"orderable": false		
						}
					],
					"aoColumns" : [
						{
							"mData": "0"
						},
						{
							"mData": "1"
						},
						{
							"mData": "2"
						},
						{
							"mData": "3"
						},
					] 
				});

				$(".tanggal").datepicker({
					autoclose: true,
					format: "yyyy:mm:dd",
					todayHighlight: true,
					orientation: "top auto",
					todayBtn: true
				});
				
				$("#btnSave").attr("disabled", false);
			});
		
			function reload_datatable() {
				datatable.ajax.reload(null, false);
			} 
		
			function showModalTambahAdmin() {
				saveMethod = 'save';
    			$("#modal-form").modal("show"); // show bootstrap modal
    			$('#form')[0].reset(); // reset form on modals
    			$('.form-group').removeClass('has-error'); // clear error class
    			$('.help-block').empty(); // clear error string
    			$('.modal-title').text('Tambah Administrator'); // Set Title to Bootstrap modal title
			}
			
			function onBtnSave() {
				$("#btnSave").text("Saving...");
				$("#btnSave").attr("disabled", true);
				
				if(saveMethod == 'save') {
					$.ajax({
						url: "http://localhost/lbslaundry/index.php/admin/ajax_save",
						async: true,
						data: $("#form").serialize(), 
						type: "POST",
						dataType: "JSON",
						success: function(result){
							if(result.status) {
								$("#btnSave").text("Save");
								$("#btnSave").attr("disabled", false);
								$("#modal-form").modal("hide");
								
								reload_datatable();
							}
	    				},
	    				error: function() {
	    					alert("Failure");
						}
					});
				} else {
					$.ajax({
						url: "http://localhost/lbslaundry/index.php/admin/ajax_update/"+ this.id,
						async: true,
						data: $("#form").serialize(), 
						type: "POST",
						dataType: "JSON",
						success: function(result){
							if(result.status) {
								$("#btnSave").text("Save");
								$("#btnSave").attr("disabled", false);
								$("#modal-form").modal("hide");
								
								reload_datatable();
							}
	    				},
	    				error: function() {
	    					$("#btnSave").text("Save");
							$("#btnSave").attr("disabled", false);
	    					alert("Failure");
						}
					});
				}
			}
			
			function onShowDialogDeleteAdmin(id) {
				this.id = id;
				$(".modal-title").text("Delete Admin");
				$("#btnDeleteAdmin").attr("disabled", false);
				
				$.ajax({
					async: true,
					type: "GET",
					url: "http://localhost/lbslaundry/index.php/admin/ajax_get_admin_by_id/"+ id,
					dataType: "JSON",
					success: function(response) {
						var admin = response[0];
						
						$("#modal-delete-content").text("Anda akan menghapus "+ admin.nama);
						$("#modal-delete").modal("show");
					}, 
					error: function() {
						alert("Failure");
					}
				});
			}
						
			function onBtnDelete() {
				$("#btnDeleteAdmin").attr("disabled", true);
				$("#btnDeleteAdmin").text("Deleting...");
				
				$.ajax({
					async: true,
					type: "GET",
					dataType: "JSON",
					url: "http://localhost/lbslaundry/index.php/admin/ajax_delete/"+ this.id,
					success: function(response) {
						if(response.status) {
							$("#modal-delete").modal("hide");
							$("#btnDeleteAdmin").text("Delete");
							$("#btnDeleteAdmin").attr("disabled", false);
							
							reload_datatable();
						}
					},
					error: function() {
						alert("Failure");
					}
				});
			}
			
			function onShowDialogEditAdmin(nim) {						
				saveMethod = 'update';
				this.id = nim;
				var that = this;
				
				$("#form")[0].reset();
				$(".form-group").removeClass("has-error");
				$(".help-block").empty();
				$(".modal-title").text("Edit Admin");
				
				$.ajax({
					async: true,
					url: "http://localhost/lbslaundry/index.php/admin/ajax_get_admin_by_id/"+ that.id,
					type: "POST",
					dataType: "JSON",
					success: function(response) {
						var admin = response[0];
						
						$("[name='nim']").val(admin.nim);
						$("[name='nama']").val(admin.nama);
						$("[name='alamat']").val(admin.alamat);
						$("[name='password']").val(admin.password);
						$("[name='kontak']").val(admin.kontak);
						$("[name='tgl-lahir']").datepicker("update", admin.tgl_lahir);
						$("#modal-form").modal("show");
    				},
    				error: function() {
    					alert("Failure");
					}
				});
			}
		</script>
		<!-- Bootstrap delete admin modal -->
		<div class="modal fade" id="modal-delete" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		                <h3 class="modal-title">Delete Administrator</h3>
					</div>
					<div class="modal-body">
						<p id="modal-delete-content"></p>
					</div>
					<div class="modal-footer">
						<button type="button" id="btnDeleteAdmin" onclick="onBtnDelete()" class="btn btn-primary" disabled="false">Delete</button>
		                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
					</div>
				</div>
			</div>
		</div>
		<!-- delete modal end -->
		<!-- Bootstrap modal -->
		<div class="modal fade" id="modal-form" role="dialog">
		    <div class="modal-dialog">
		        <div class="modal-content">
		            <div class="modal-header">
		                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		                <h3 class="modal-title">Form Administrator</h3>
		            </div>
		            <div class="modal-body form">
		                <form action="<?php echo base_url() ?>index.jsp/admin/ajax_save" id="form" class="form-horizontal">
		                    <input type="hidden" value="" name="id"/>
		                    <div class="form-body">
		                        <div class="form-group">
		                            <label class="control-label col-md-3">NIM</label>
		                            <div class="col-md-9">
		                                <input name="nim" placeholder="Nomor induk mahasiswa" class="form-control" type="text">
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                        <div class="form-group">
		                            <label class="control-label col-md-3">Nama Lengkap</label>
		                            <div class="col-md-9">
		                                <input name="nama" placeholder="Nama lengkap mahasiswa" class="form-control" type="text">
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                        <div class="form-group">
		                            <label class="control-label col-md-3">Password</label>
		                            <div class="col-md-9">
		                                <input name="password" placeholder="Password maksimal 45 karakter" class="form-control" type="password">
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                        <div class="form-group">
		                            <label class="control-label col-md-3">Jenis Kelamin</label>
		                            <div class="col-md-9">
		                                <select name="jenis-kelamin" class="form-control">
		                                    <option value="">-- Pilih Jenis --</option>
		                                    <option value="pria">Pria</option>
		                                    <option value="wanita">Wanita</option>
		                                </select>
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                        <div class="form-group">
		                            <label class="control-label col-md-3">Alamat</label>
		                            <div class="col-md-9">
		                                <textarea name="alamat" placeholder="Alamat" class="form-control"></textarea>
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                        <div class="form-group">
		                            <label class="control-label col-md-3">Kontak</label>
		                            <div class="col-md-9">
		                                <input name="kontak" placeholder="8943433232" class="form-control" type="text">
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                        <div class="form-group">
		                            <label class="control-label col-md-3">Tanggal Lahir</label>
		                            <div class="col-md-9">
		                                <input name="tgl-lahir" placeholder="yyyy-mm-dd" class="form-control tanggal" type="text">
		                                <span class="help-block"></span>
		                            </div>
		                        </div>
		                    </div>
		                </form>
		            </div>
		            <div class="modal-footer">
		                <button type="button" id="btnSave" onclick="onBtnSave()" class="btn btn-primary" disabled="false">Save</button>
		                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
		            </div>
		        </div><!-- /.modal-content -->
		    </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->
		<!-- End Bootstrap modal -->
	</body>
</html>

