<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Laundry Online</title>

		<!-- Bootstrap Core CSS -->
		<link href="<?php echo base_url(); ?>/assets/css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery.js"></script>
		<style type="text/css">
			.header img {
				height: 200px;
				width: 945px;
			}

			body {
				margin: 10px;
			}

			.content {
				background-color: blue;
			}

			.no-margin {
				margin: 0px; 
			}
		</style>
	</head>
	<body>
		<div class="container">
			<?php 
			include("header.php");
			?>
			<?php
				$i = 0;
				
				foreach($records as $i=>$row){
				
				$i++;
				?>
				<div class="row">
					<div class="col-md-1"></div>
					<div class="col-md-3">
						<a href="#">
							<?php 
								$obj = $row['foto'];
								$foto = $obj[0];
							 ?>
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/images/uploaded_images/laundry_images/<?php echo $foto->foto; ?>" alt="">
						</a>
					</div>
					<div class="col-md-7">
						<h3 class="no-margin"><?php echo $row['nama_laundry'] ?></h3>
						<p class="no-margin"><?php echo $row['alamat'] ?></p>
						<a class="btn btn-success" href="<?php echo base_url(); ?>index.php/edit/edit_laundry/<?php echo $row['id_laundry'] ?>">Edit</a>
						<a id="<?php echo $i ?>" class="btn btn-danger delete-laundry-modal" data-toggle="modal" data-target=".modal-delete-<?php echo $i ?>">Delete</a>
						<div class="modal fade modal-delete-<?php echo $i ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title" id="myModalLabel">Konfirmasi</h4>
									</div>
									<div class="modal-body">
										<p>Anda akan mengapus <span id="id-content-<?php echo $i ?>"><?php echo $row['nama_laundry'] ?></span></p>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
										<button id="btn-delete-<?php echo $i ?>" type="button" class="btn btn-danger">Delete</button>
										<script>
											$("#btn-delete-<?php echo $i ?>").click(function() {
												alert("hai "+ <?php echo $i ?>);
											});
										</script>
									</div>
								</div>
							</div>
						</div>			
						<a class="btn btn-primary" href="<?php echo base_url(); ?>index.php/detail_laundry/get_detail/<?php echo $row['id_laundry']; ?>">View Details <span class="glyphicon glyphicon-chevron-right"></span></a>
					</div>
					<div class="col-md-1"></div>
				</div>
				<br/>
				<br/>					
				<?php } ?>
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-11">
					<div class="pagination">
						<?php
						foreach($links as $link){
							echo "<li>". $link ."</li>";
						}
						?>
					</div>
				</div>
			</div>
		</div>	
		<script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
	</body>
</html>
