<html>
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="">

	    <title>Laundry Online</title>

	    <!-- Bootstrap Core CSS -->
	    <link href="<?php echo base_url(); ?>/assets/css/bootstrap.css" rel="stylesheet">
		<script src="<?php echo base_url(); ?>/assets/js/bootstrap-filestyle.min.js"></script>
		<script src="<?php echo base_url(); ?>/assets/js/jquery.validate.min.js"></script>
		<script src="https://code.jquery.com/jquery.js"></script>
	    <style type="text/css">
	    	.header img {
	    		height: 200px;
	    		width: 945px;
	    	}

	    	body {
	    		margin: 10px;
	    	}

	    	.content {
	    		background-color: blue;
	    	}

	    	.no-margin {
	    		margin: 0px;
	    	}

			#form-border {
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				border-bottom: 1px solid #E0E0E0;
				padding: 25px 20px 25px 20px;
				border-radius: 0px 0px 5px 5px;
			}

			#form-header {
				border-top: 1px solid #E0E0E0;
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				background-color: #FFF9C4;
				padding: 20px 10px 20px 10px;
				border-radius: 5px 5px 0px 0px;
			}

			#separator {
				border-top: 1px solid #E0E0E0;
				display: inline block;
			}

			.form-width {
				width: 700px;
			}

			.btn-file {
				position: relative;
				overflow: hidden;
			}

			.btn-file input[type=file] {
				position: absolute;
				top: 0;
				right: 0;
				min-width: 100%;
				min-height: 100%;
				font-size: 100px;
				text-align: right;
				filter: alpha(opacity=0);
				opacity: 0;
				outline: none;
				background: white;
				cursor: inherit;
				display: block;
			}
			
			input[type=file] {
				width:90px;
    			color:transparent;
			}
	    </style>
	</head>
	<body>
		<div class="container">
			<?php
				include("header.php");
				$laundry_obj = $laundry[0];
				$laundry_foto = $foto;
			?>
			<div class="row">
				<div class="col-md-1"></div>
		            <div class="col-md-10">
						<div id="form-header">
							<h4 class="no-margin">Halaman ini berfungsi untuk mengedit data laundry</h4>
						</div>
						<div id="separator"></div>
						<div id="form-border">
							<?php
								$attributes = array(
									"id" => "form-laundry"
								);
								echo form_open_multipart("edit/submitted_update_laundry", $attributes);
								echo "<div class='form-group' style='width: 400px'>";
								
								$data = array(
									"name" => "id-laundry",
									"type" => "hidden",
									"id" => "id-laundry",
									"class" => "form-control",
									"value" => "$laundry_obj->id_laundry",
									"placeholder" => "Masukkan nama laundry", 
								);
								
								echo form_input($data);
								
								echo form_label("Nama Laundry", "nama laundry");

								$data = array(
									"name" => "nama-laundry",
									"type" => "text",
									"id" => "nama-laundry",
									"class" => "form-control",
									"value" => "$laundry_obj->nama_laundry",
									"placeholder" => "Masukkan nama laundry", 
								);
								echo form_input($data);
								echo "</div>";

								echo "<div class='form-group' style='width: 700px'>";
								echo form_label("Alamat", "alamat");

								$data = array(
									"name" => "alamat",
									"type" => "text",
									"id" => "alamat",
									"value" => "$laundry_obj->alamat",
									"class" => "form-control",
									"placeholder" => "Masukkan alamat",
								);

								echo form_input($data);
								echo "</div>";

								echo form_label("Kontak", "kontak");
								echo "<div class='input-group col-md-5'>";
								echo "<span class='input-group-addon' id='basic-addon1'>No HP</span>";

								$data = array(
									"name" => "no-hp",
									"type" => "number",
									"id" => "no-hp",
									"value" => "$laundry_obj->no_hp",
									"placeholder" => "contoh : 085000898797",
									"class" => "form-control",
									"aria-describedby" => "basic-addon1"
								);

								echo form_input($data);
								echo "</div>";
								echo "</br>";
								echo "<div class='form-group' style='width: 355px'>";
								echo form_label("Latitude Longitude", "latitude_longitude");

								$data = array(
									"name" => "latitude_longitude",
									"type" => "text",
									"id" => "latitude_longitude",
									"class" => "form-control",
									"value" => $laundry_obj->latitude .':'. $laundry_obj->longitude,
									"placeholder" => "4773874.474, 48394348.484",
								);

								echo form_input($data);
							?>
								<small><font color="red">NB:</font> Masukkan latitude dan longitude dengan pemisah semicolon (:)</small>
								<div id="map" style="margin-top: 10dp"></div>
							<?php
								echo "</div>";

								echo "<div class='form-group' style='width: 450px'>";

								echo form_label("Deskripsi", "deskripsi");

								$data = array(
									"name" => "deskripsi",
									"type" => "text",
									"id" => "deskripsi",
									"class" => "form-control",
									"maxlength" => "300",
									"size" => "80",
									"value" => "$laundry_obj->deskripsi",
									"placeholder" => "Masukkan deskripsi",
								);

								echo form_textarea($data);
								echo "<small>Deskripsi laundry (maksimal 300 kata)</small>";
								echo "</div>";

								echo "<div class='form-group' style='width: 450px'>";
								
								echo form_label("Foto", "foto");
								
								//configuration for foto1
								$foto1 = $laundry_foto[0];

								$data = array(
									"name" => "foto1",
									"type" => "file",
									"title" => "foto1",
									"value" => base_url() .'assets/images/uploaded_images/laundry_images/'. $foto1->foto,  
									"onchange" => "readURL(this, '#lbl-foto1', '#preview-foto1');",
									"id" => "foto1",
								);

								echo form_input($data); 
								
								$data = array(
									"name" => "foto1-time-id",
									"type" => "hidden",
									"value" => $foto1->time, 
								);

								echo form_input($data); ?>
								
								<span id="lbl-foto1"><?php echo $foto1->foto ?></span><br/>
								<?php
								echo "<img name='img1' id='preview-foto1' src='". base_url() ."assets/images/uploaded_images/laundry_images/".$foto1->foto ."' style='width: 150px; heigth: 150px;'/>";
								echo "<br/><br/>";
								
								//configuration for foto2
								$foto2 = $laundry_foto[1];
								
								if($foto2 != null){
									$data = array(
										"name" => "foto2",
										"type" => "file",
										"title" => "foto2",
										"src" => base_url() .'assets/images/uploaded_images/laundry_images/'. $foto2->foto,  
										"onchange" => "readURL(this, '#lbl-foto2', '#preview-foto2');",
										"id" => "foto2",
									);

									echo form_input($data); 
													
									$data = array(
										"name" => "foto2-time-id",
										"type" => "hidden",
										"value" => $foto2->time
									);

									echo form_input($data);
								}
								?>
								<span id="lbl-foto2"><?php echo $foto2->foto ?></span><br/>
								<?php
								echo "<img id='preview-foto2' src='". base_url() ."assets/images/uploaded_images/laundry_images/".$foto2->foto ."' style='width: 150px; heigth: 150px;'/>";
								echo "<br/><br/>";

								//configuration for foto3
								$foto3 = $laundry_foto[2];
								
								$data = array(
									"name" => "foto3",
									"type" => "file",
									"title" => "foto3",
									"src" => base_url() .'assets/images/uploaded_images/laundry_images/'. $foto3->foto,  
									"onchange" => "readURL(this, '#lbl-foto3', '#preview-foto3');",
									"id" => "foto3",
								);

								echo form_input($data); 
												
								$data = array(
									"name" => "foto3",
									"type" => "hidden",
									"value" => $foto3->time
								);

								echo form_input($data); 
								
								?>
								<span id="lbl-foto3"><?php echo $foto3->foto ?></span><br/>
								<?php
								echo "<img id='preview-foto3' src='". base_url() ."assets/images/uploaded_images/laundry_images/".$foto3->foto ."' style='width: 150px; heigth: 150px;'/>";
								echo "<br/><br/>";
								// end of foto configuration
								
								echo form_label("Harga Per Kg", "harga-per-kg");
								echo "<div class='input-group col-md-5'>";
								echo "<span class='input-group-addon' id='basic-addon1'>Rp</span>";

								$data = array(
									"name" => "harga",
									"type" => "number",
									"id" => "harga",
									"placeholder" => "Masukkan harga",
									"class" => "form-control",
									"value" => "$laundry_obj->harga",
									"aria-describedby" => "basic-addon1"
								);

								echo form_input($data);
								echo "</div>";
								echo "<br/>";
								echo "<br/>";
								echo "<div class='form-group'>";

								$data = array(
									"name" => "submit",
									"type" => "submit",
									"value" => "Simpan",
									"class" => "btn btn-primary"
								);

								echo form_input($data);
								echo "</div>";
							?>

						</div>
					</div>
		        <div class="col-md-1"></div>
        	</div>
		</div>
		<script>
			function readURL(input, lblId, imgId) {
				var file = input.files[0];
				var fileReader = new FileReader();
				
				if(input.files && file) {
					fileReader.onload = function(e) {
						$(imgId).attr('src', e.target.result);
					}

					$(lblId).html(file.name);
					fileReader.readAsDataURL(file);
				}
			}
		</script>
	</body>
</html>



