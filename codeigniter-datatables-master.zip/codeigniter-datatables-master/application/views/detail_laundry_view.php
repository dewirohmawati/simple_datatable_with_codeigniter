<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<title>Laundry Online</title>

    	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script> 
		<!-- Bootstrap Core CSS -->
		<link href="<?php echo base_url(); ?>/assets/css/bootstrap.css" rel="stylesheet">
		<script src="<?php echo base_url(); ?>/assets/js/bootstrap-filestyle.min.js"></script>
		<script src="<?php echo base_url(); ?>/assets/js/jquery.validate.min.js"></script>
		<!-- you can use these links, but better you have a link to the versions you need -->
    	<!-- usage of folder "current" is not recommended -->
    	<!-- see http://beaverslider.com/how-to-setup/docs/general for more info -->
    	<script src="http://beaverslider.com/code/current/beaverslider.js"></script>         <!-- link to a framework -->
		<script src="http://beaverslider.com/code/current/beaverslider-effects.js"></script> <!-- link to a set of effects -->
	
		<style type="text/css">
			.header img {
				height: 200px;
				width: 945px;
			}

			body {
				margin: 10px;
			}

			.content {
				background-color: blue;
			}

			.no-margin {
				margin: 0px;
			}

			#form-border {
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				border-bottom: 1px solid #E0E0E0;
				padding: 25px 20px 25px 20px;
				border-radius: 0px 0px 5px 5px;
			}

			#form-header {
				border-top: 1px solid #E0E0E0;
				border-left: 1px solid #E0E0E0;
				border-right: 1px solid #E0E0E0;
				background-color: #FFF9C4;
				padding: 20px 10px 20px 10px;
				border-radius: 5px 5px 0px 0px;
			}

			#separator {
				border-top: 1px solid #E0E0E0;
				display: inline block;
			}

			.form-width {
				width: 700px;
			}

			.btn-file {
				position: relative;
				overflow: hidden;
			}

			.btn-file input[type=file] {
				position: absolute;
				top: 0;
				right: 0;
				min-width: 100%;
				min-height: 100%;
				font-size: 100px;
				text-align: right;
				filter: alpha(opacity=0);
				opacity: 0;
				outline: none;
				background: white;
				cursor: inherit;
				display: block;
			}
			
			#form-border p {
				color: #a09492;
			}
			
			#form-border h3 {
				color: #555852;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<?php
				include("header.php");
			?>
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">
					<div id="form-header">
						<h4 class="no-margin">Detail laundry <?php echo $laundry->nama_laundry ?></h4>
					</div>
					<div id="separator"></div>
					<div id="form-border">
						<h3>Nama Laundry</h3>
						<p><?php echo $laundry->nama_laundry ?></p>
						<hr/>
						<h3>Harga per Kg</h3>
						<p style="color: #ff0f0f" id="harga"></p>
						<hr/>
						<h3>Alamat</h3>
						<p><?php echo $laundry->alamat ?></p>
						<hr/>
						<h3>Kontak</h3>
						<p><?php echo $laundry->no_hp ?></p>
						<hr/>
						<h3>Deskripsi</h3>
						<p><?php echo $laundry->deskripsi ?></p>
						<hr/>
						<h3>Peta</h3>
						<div id="map" style="height: 300px; width: 450px;"></div>
						<hr/>
						<div id="slider"></div>
					</div>
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
		<script>
			var laundry_foto = [];
			var i = 0;
			<?php 
				foreach($foto as $obj) { ?>
					laundry_foto[i] = '<?php echo base_url() ."assets/images/uploaded_images/laundry_images/". $obj->foto ?>';

					i++;
			<?php
				} 
			?>
			
			$(function(){
	      		$("#harga").html(toRp(<?php echo $laundry->harga; ?>));
			});
			
			var latitude = <?php echo $laundry->latitude ?>;
			var longitude = <?php echo $laundry->longitude ?>;
			
			function initMap() {
				map = new google.maps.Map(document.getElementById("map"), {
						center: {
							lat: latitude, 
							lng: longitude
						},
						zoom: 15
				});
			}
			
			
			function toRp(digit) {
				var digitReverse = parseInt(digit, 10).toString().split('').reverse().join('');
				var formattedDigit = '';
				
				for(var i = 0; i < digitReverse.length; i++) {
					formattedDigit += digitReverse[i];
					
					if((i + 1) % 3 === 0 && i !== (digitReverse - 1))
						formattedDigit += '.';
				}
				
				return 'Rp. '+ formattedDigit.split('').reverse().join('') +',00';
			}
		</script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCkErBkJIkqzD0-2aHPIGC4HCdl4C2CQ6o&callback=initMap"
    async defer></script>
	</body>
</html>









