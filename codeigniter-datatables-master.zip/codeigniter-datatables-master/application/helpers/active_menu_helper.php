<?php 
	function activate_menu($controller) {
		$CI_Object = get_instance();
		$currentClass = $CI_Object->router->fetch_class();
		
		return 'active';
	}
?>